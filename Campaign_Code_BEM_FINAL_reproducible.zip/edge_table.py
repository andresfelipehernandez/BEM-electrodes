"""D-N edge refinement campaign used for Table 3/Table 4 and Figures 2-3.
The K_1/2 and alpha estimates are reported only when >=6 panels lie in the
fixed physical fitting window, exactly as stated in the manuscript.
"""
import warnings, pickle, csv
warnings.filterwarnings('ignore')
import numpy as np
from mixed import run

W=(1e-6,1e-5)
LEVELS=list(range(12,55,6))+[72,90,120]
rows=[]
for na in LEVELS:
    r=run(na)
    J,rho=r['J'],r['rho']
    o=np.argsort(rho)
    # Exclude the single panel adjacent to the D-N junction.
    J2,rho2=J[o][1:],rho[o][1:]
    sel=(rho2>=W[0])&(rho2<=W[1])
    n=int(sel.sum())
    if n>=6:
        K=float(np.median(J2[sel]*np.sqrt(rho2[sel])))
        a=float(-np.polyfit(np.log(rho2[sel]),np.log(J2[sel]),1)[0])
    else:
        K=np.nan; a=np.nan
    rows.append(dict(na=na,ni=4*na,no=16*na//3,rmin=r['rmin'],Jmax=r['Jmax'],
                     alpha=a,K=K,n=n,prod=r['prod'],res=r['res'],eps=r['eps'],J=J,rho=rho))
    print(na,4*na,16*na//3,f"{r['rmin']:.3e} {r['Jmax']:.1f} a={a:.4f} K={K:.4f} "
          f"n={n} prod={r['prod']:.4f} res={r['res']:.2e} eps={r['eps']:.2e}",flush=True)

with open('edge.pkl','wb') as f: pickle.dump(rows,f)
with open('outputs/edge_study.csv','w',newline='') as f:
    w=csv.writer(f)
    w.writerow(['active','insulated','outer','rho_min_m','Jmax_A_m2','Jsqrtrho_closest',
                'n_window','alpha','K12','BIE_residual','eps_I'])
    for x in rows:
        w.writerow([x['na'],x['ni'],x['no'],x['rmin'],x['Jmax'],x['prod'],x['n'],
                    x['alpha'],x['K'],x['res'],x['eps']])
rho=np.array([x['rmin'] for x in rows]); Jm=np.array([x['Jmax'] for x in rows])
print('global slope',np.polyfit(np.log(rho),np.log(Jm),1)[0],
      'first8',np.polyfit(np.log(rho[:8]),np.log(Jm[:8]),1)[0])
