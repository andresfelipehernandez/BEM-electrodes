from bem import *
from scipy.optimize import brentq
Ri,Re,V0,s=2e-3,4e-3,2.0,0.15
al=np.deg2rad(15.75); g=1.28
def graded(S,m,first=None,gg=g):
    """m panel lengths over S, smallest at the START, geometric."""
    if first is not None:
        gg=brentq(lambda x: first*(x**m-1)/(x-1)-S,1.0000001,5)
    L=gg**np.arange(m); return L*S/L.sum()
def both_ends(S,m,first=None):
    h=graded(S/2,m//2,first); return np.r_[h,h[::-1]]
def mesh(na):
    Sa=2*al*Ri; La=both_ends(Sa,na)
    Si=(2*np.pi-2*al)*Ri; Li=both_ends(Si,4*na,first=La[0])
    # angles: start at -al going CCW through active then insulated
    L=np.r_[La,Li]; th=-al+np.r_[0,np.cumsum(L)[:-1]]/Ri
    inner=circle(Ri,None,False,th=-th)   # reverse sign handled: circle(ccw=False) negates; give -th to get th, then reverse order for CW
    inner=np.c_[Ri*np.cos(th),Ri*np.sin(th)][::-1]   # CW ordering
    nout=16*na//3
    P=Panels([(circle(Re,nout),'out'),(inner,'in')])
    return P
def run(na,win=(2e-5,1e-4)):
    P=mesh(na); thm=np.arctan2(P.m[:,1],P.m[:,0]); inn=P.tag=='in'
    act=inn&(np.abs(thm)<=al); ins=inn&~act
    isD=~ins; val=np.where(act,V0,0.0)
    V,q,res=solve(P,isD,val,return_res=True)
    # BC residuals trivially zero (prescribed); current balance
    Iin=(s*q[inn]*P.L[inn]).sum(); Iout=(s*q[~inn]*P.L[~inn]).sum()
    eps=abs(Iin+Iout)/abs(Iin)
    # active panels, upper junction (theta=+al): rho = Ri*(al - theta)
    J=s*np.abs(q[act]); rho=Ri*(al-np.abs(thm[act]))
    k=np.argmin(rho); Jmax=J.max()
    def K_alpha(w):
        sel=(rho>=w[0])&(rho<=w[1])
        K=np.median(J[sel]*np.sqrt(rho[sel])); a=-np.polyfit(np.log(rho[sel]),np.log(J[sel]),1)[0]
        return K,a,sel.sum()
    K,a,nw=K_alpha(win)
    return dict(na=na,ni=4*na,no=16*na//3,rmin=rho.min(),Jmax=Jmax,JmaxNear=J[k],prod=J[k]*np.sqrt(rho[k]),K=K,alpha=a,nwin=nw,res=res,eps=eps,J=J,rho=rho,KA=K_alpha)
if __name__=='__main__':
    for na in range(12,55,6):
        r=run(na); print(na,f"{r['rmin']:.3e} {r['Jmax']:.1f} {r['alpha']:.4f} {r['K']:.4f} {r['prod']:.4f} nw={r['nwin']} res={r['res']:.2e} eps={r['eps']:.2e}",flush=True)
