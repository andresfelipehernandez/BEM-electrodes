"""bem.py - 2D Laplace BEM with straight constant panels (midpoint collocation).
Conventions: r = y - x, outward normal n, q = dV/dn, E = -grad V, J = sigma E.
c(x)V(x) + int V dG/dn_y = int G q,  G = -(1/2pi) ln|x-y|, c = 1/2 at panel midpoints.
Off-diagonal integrals: closed-form analytic (ng=None) or Gauss-Legendre with ng points.
Self terms: H_ii = 0 (straight panel) plus c = 1/2; G_ii analytic (log singularity)."""
import numpy as np

class Panels:
    def __init__(self, loops):
        """loops: list of (points (n,2) ordered so that domain lies to the LEFT, tag)."""
        A=[];B=[];T=[]
        for pts,tag in loops:
            A.append(pts); B.append(np.roll(pts,-1,axis=0)); T += [tag]*len(pts)
        self.a=np.vstack(A); self.b=np.vstack(B); self.tag=np.array(T)
        d=self.b-self.a; self.L=np.hypot(d[:,0],d[:,1]); self.t=d/self.L[:,None]
        self.n=np.c_[self.t[:,1],-self.t[:,0]]          # outward (domain on the left)
        self.m=0.5*(self.a+self.b); self.N=len(self.L)

def influence(X, P, ng=None):
    """Return Hhat (int dG/dn_y) and G (int G) for source points X over panels P."""
    dx=X[:,None,:]-P.m[None,:,:]
    xi0=np.einsum('ijk,jk->ij',dx,P.t); eta=np.einsum('ijk,jk->ij',dx,P.n)
    h=0.5*P.L[None,:]
    if ng is None:
        x1=-h-xi0; x2=h-xi0; y=eta
        ang=np.arctan2(y*(x2-x1), x1*x2+y*y)
        r1=np.hypot(x1,y); r2=np.hypot(x2,y)
        with np.errstate(divide='ignore',invalid='ignore'):
            t1=np.where(r1>0,x1*np.log(r1),0.0); t2=np.where(r2>0,x2*np.log(r2),0.0)
        Ilog=t2-t1-(x2-x1)+y*ang
        H=ang/(2*np.pi)      # = int -(1/2pi)(r.n)/r^2 ds with r.n = -eta
        G=-Ilog/(2*np.pi)
    else:
        s,w=np.polynomial.legendre.leggauss(ng)
        H=np.zeros(xi0.shape); G=np.zeros(xi0.shape)
        for sk,wk in zip(s,w):
            xx=sk*h-xi0; r2=xx*xx+eta*eta
            H+=wk*h*(eta/r2)/(2*np.pi)
            G+=wk*h*(-np.log(np.sqrt(r2))/(2*np.pi))
    return H,G

def matrices(P, ng=None):
    H,G=influence(P.m,P,ng)
    i=np.arange(P.N)
    if ng is not None:   # exact self terms
        Ha,Ga=influence(P.m,P,None); H[i,i]=Ha[i,i]; G[i,i]=Ga[i,i]
    H[i,i]=0.0
    return H+0.5*np.eye(P.N), G

def solve(P, isD, val, ng=None, return_res=False):
    H,G=matrices(P,ng)
    A=np.where(isD[None,:],-G,H); B=np.where(isD[None,:],H,-G)
    rhs=-(B@val); x=np.linalg.solve(A,rhs)
    V=np.where(isD,val,x); q=np.where(isD,x,val)
    res=np.linalg.norm(A@x-rhs)/np.linalg.norm(rhs)
    return (V,q,res) if return_res else (V,q)

def circle(R, n, ccw=True, c=(0.0,0.0), th=None):
    if th is None: th=2*np.pi*np.arange(n)/n
    th=np.asarray(th) if ccw else -np.asarray(th)
    return np.c_[c[0]+R*np.cos(th), c[1]+R*np.sin(th)]
