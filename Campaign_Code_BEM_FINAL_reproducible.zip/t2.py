from bem import *
Ri,Re,V0,s,d=2e-3,4e-3,2.0,0.15,0.7e-3
xb=(Ri*Ri-Re*Re-d*d)/(2*d); xa=xb+d; c=np.sqrt(xb*xb-Re*Re)
# shift so outer centre at origin: outer centre xb -> 0
def xi(X): x=X[:,0]+xb; y=X[:,1]; return np.arctanh(2*c*x/(x*x+y*y+c*c))
xia=xi(np.array([[d+Ri,0.]]))[0]; xib=xi(np.array([[Re,0.]]))[0]
def gradV(X):
    h=1e-9; gx=(xi(X+[h,0])-xi(X-[h,0]))/(2*h); gy=(xi(X+[0,h])-xi(X-[0,h]))/(2*h)
    k=V0/(xia-xib); return k*np.c_[gx,gy]
def ecc(n):
    P=Panels([(circle(Re,2*n),'out'),(circle(Ri,n,False,c=(d,0)),'in')])
    isD=np.ones(P.N,bool); val=np.where(P.tag=='in',V0,0.0); V,q=solve(P,isD,val)
    ii=P.tag=='in'
    # exact q at the point of the true circle at the same angle as midpoint
    th=np.arctan2(P.m[ii,1],P.m[ii,0]-d); Xc=np.c_[d+Ri*np.cos(th),Ri*np.sin(th)]
    nC=-np.c_[np.cos(th),np.sin(th)]
    qex=(gradV(Xc)*nC).sum(1)
    e=np.linalg.norm(q[ii]-qex)/np.linalg.norm(qex)
    return e, np.abs(q[ii]).max(), np.abs(qex).max()
if __name__=="__main__":
  for n in [24,36,48,72,96,144]:
    e,Em,Ee=ecc(n); print(n,e,Em,Ee,(Em-1969.429)/1969.429)
