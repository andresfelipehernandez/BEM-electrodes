"""One-command reproduction of all numerical campaigns and manuscript figures."""
import subprocess,sys,os
os.makedirs('outputs',exist_ok=True); os.makedirs('figs',exist_ok=True)
for script in ['campaign.py','edge_table.py','export_tables.py','figs4.py']:
    print(f'\n=== {script} ===',flush=True)
    subprocess.run([sys.executable,script],check=True)
print('\nCampaign completed. Tables: outputs/ ; figures: figs/')
