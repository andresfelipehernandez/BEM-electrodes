# Reproducibility package — BEM electrode-edge verification campaign

This package reproduces the numerical results and Figures 1–6 of the manuscript **“Mesh-independent edge metrics for partially insulated electrodes: A verified boundary element analysis in annular conductive media.”**

## Requirements
Python 3.10+ with NumPy, SciPy, Matplotlib and Pillow. Install with:

    python -m pip install -r requirements.txt

## Reproduce everything
From this directory run:

    python run_all.py

Generated numerical tables are written to `outputs/` and publication figures to `figs/` (PNG and TIFF, 600 dpi).

## Files
- `bem.py`: 2D Laplace BEM, straight discontinuous constant panels, midpoint collocation, closed-form panel integrals; optional Gauss-Legendre evaluation of regular terms.
- `campaign.py`: concentric benchmark, quadrature study, eccentric benchmark, multidomain benchmark, independent P1 FEM, and BEM interior-potential comparison.
- `t2.py`: exact eccentric-annulus solution in bipolar coordinates.
- `mixed.py`: partially insulated electrode with exact D-N transition and geometrically graded panels.
- `edge_table.py`: eleven-mesh edge campaign. It excludes the panel adjacent to the junction and reports alpha and K_1/2 only when at least six panels fall in the fixed window 1e-6 <= rho <= 1e-5 m, matching the manuscript.
- `md.py`: two-layer multidomain BEM benchmark.
- `fem.py`: independent sparse P1 FEM and common-point BEM comparison.
- `export_tables.py`: exports campaign results to CSV.
- `figs4.py`: reproduces Figures 1–6.
- `run_all.py`: one-command driver.

## Numerical conventions
`r = y - x`, outward normal `n`, `q = dV/dn`, `E = -grad(V)`, `J = sigma E`, and `G = -(1/(2*pi))*ln|x-y|`. Boundaries are oriented so that the computational domain lies to the left of panel traversal.

## Reproducibility note
Floating-point residuals near machine precision and wall-clock timings can vary slightly with BLAS/LAPACK, Python version, operating system and hardware. Convergence errors, singular exponents and regularized edge coefficients should reproduce to the reported significant digits.
