import warnings, json, pickle, time; warnings.filterwarnings('ignore')
import numpy as np
from bem import *
import t2 as ecc_mod
from md import run as md_run, VIex,q0ex,qIex,I as Imd
from fem import fem, bem_int, Vex
Ri,Re,V0,s=2e-3,4e-3,2.0,0.15
out={}
def conc(n,ng=None):
    P=Panels([(circle(Re,2*n),'out'),(circle(Ri,n,False),'in')])
    isD=np.ones(P.N,bool); val=np.where(P.tag=='in',V0,0.0); V,q=solve(P,isD,val,ng)
    ii=P.tag=='in'; qex=V0/(Ri*np.log(Re/Ri))
    e=np.linalg.norm(q[ii]-qex)/(qex*np.sqrt(ii.sum()))
    Iin=(s*q[ii]*P.L[ii]).sum(); Iout=(s*q[~ii]*P.L[~ii]).sum()
    return e,abs(Iin+Iout)/abs(Iin)
out['conc']=[(n,*conc(n)) for n in [24,36,48,72,96,144]]
out['quad']=[(ng,conc(48,ng)[0]) for ng in [2,4,6,8,12,16]]+[('analytic',conc(48)[0])]
out['ecc']=[(n,*ecc_mod.ecc(n)) for n in [24,36,48,72,96,144]]
out['md']=[(m,*md_run(*m)) for m in [(16,24,32),(24,32,48),(32,48,64),(48,64,96),(64,96,128),(96,128,192)]]
out['fem']=[fem(nr,nt) for nr,nt in [(4,24),(5,32),(7,48),(9,64),(11,80)]]
r=np.linspace(Ri,Re,11)[1:-1]; th=2*np.pi*np.arange(80)/80
R,T=np.meshgrid(r,th,indexing='ij'); X=np.c_[(R*np.cos(T)).ravel(),(R*np.sin(T)).ravel()]
out['bemint']=[(n,*bem_int(n,X)) for n in [24,36,48,72,96,144]]
json.dump(out,open('results.json','w'),default=float,indent=1)
for k,v in out.items():
    print(k); [print('  ',x) for x in v]
