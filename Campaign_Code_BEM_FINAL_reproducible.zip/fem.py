import numpy as np, time, tracemalloc, scipy.sparse as sp, scipy.sparse.linalg as spl
from bem import *
a,b,V0=2e-3,4e-3,2.0
Vex=lambda r: V0*np.log(b/r)/np.log(b/a)
def fem(nr,nt):
    tracemalloc.start(); t0=time.perf_counter()
    r=np.linspace(a,b,nr); th=2*np.pi*np.arange(nt)/nt
    R,T=np.meshgrid(r,th,indexing='ij'); X=np.c_[(R*np.cos(T)).ravel(),(R*np.sin(T)).ravel()]
    idx=lambda i,j: i*nt+(j%nt)
    tri=[]
    for i in range(nr-1):
        for j in range(nt):
            tri+= [[idx(i,j),idx(i+1,j),idx(i+1,j+1)],[idx(i,j),idx(i+1,j+1),idx(i,j+1)]]
    tri=np.array(tri); I=[];Jc=[];Vv=[]
    for t in tri:
        p=X[t]; B=np.array([[p[1,0]-p[0,0],p[2,0]-p[0,0]],[p[1,1]-p[0,1],p[2,1]-p[0,1]]])
        A=0.5*abs(np.linalg.det(B)); Gd=np.linalg.inv(B).T@np.array([[-1,1,0],[-1,0,1]])
        K=A*Gd.T@Gd; I+= list(np.repeat(t,3)); Jc+= list(np.tile(t,3)); Vv+= list(K.ravel())
    K=sp.csr_matrix((Vv,(I,Jc)),shape=(len(X),len(X)))
    rr=np.hypot(*X.T); bd=(np.isclose(rr,a))|(np.isclose(rr,b)); u=np.zeros(len(X)); u[np.isclose(rr,a)]=V0
    fr=~bd; u[fr]=spl.spsolve(K[fr][:,fr].tocsc(), -K[fr][:,bd]@u[bd])
    t1=time.perf_counter(); peak=tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    rm=np.sqrt(np.mean((u[fr]-Vex(rr[fr]))**2))
    return len(X),len(tri),rm,t1-t0,peak/1e6
def bem_int(n,X):
    tracemalloc.start(); t0=time.perf_counter()
    P=Panels([(circle(b,2*n),'out'),(circle(a,n,False),'in')])
    isD=np.ones(P.N,bool); val=np.where(P.tag=='in',V0,0.0); V,q=solve(P,isD,val)
    H,G=influence(X,P); Vi=G@q-H@V
    t1=time.perf_counter(); peak=tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    return P.N, np.sqrt(np.mean((Vi-Vex(np.hypot(*X.T)))**2)), t1-t0, peak/1e6
if __name__=='__main__':
    for nr,nt in [(4,24),(5,32),(7,48),(9,64),(11,80)]:
        print('FEM',*fem(nr,nt))
    # common evaluation set: interior nodes of the finest FEM grid
    r=np.linspace(a,b,11)[1:-1]; th=2*np.pi*np.arange(80)/80
    R,T=np.meshgrid(r,th,indexing='ij'); X=np.c_[(R*np.cos(T)).ravel(),(R*np.sin(T)).ravel()]
    for n in [24,36,48,72,96,144]:
        print('BEM',n,*bem_int(n,X))
