"""Export manuscript campaign results to human-readable CSV files."""
import json,csv,os
os.makedirs('outputs',exist_ok=True)
R=json.load(open('results.json'))
def write(name, header, rows):
    with open('outputs/'+name,'w',newline='') as f:
        w=csv.writer(f); w.writerow(header); w.writerows(rows)
write('table1_concentric.csv',['N_inner','rel_L2_flux_error','current_imbalance'],R['conc'])
write('quadrature.csv',['gauss_points','rel_L2_flux_error'],R['quad'])
write('table2_eccentric.csv',['N_inner','rel_L2_flux_error','BEM_Emax_V_m','exact_sample_Emax_V_m'],R['ecc'])
write('table6_multidomain.csv',['mesh','err_VI','err_q0','err_qI','current_imbalance','interface_jump'],R['md'])
write('fem.csv',['DOF','triangles','potential_RMSE_V','wall_time_s','peak_memory_MB'],R['fem'])
write('bem_interior.csv',['N_inner','BEM_DOF','potential_RMSE_V','wall_time_s','peak_memory_MB'],R['bemint'])
print('CSV tables written to outputs/')
