from bem import *
a,rI,b,V0,s1,s2=2e-3,2.5e-3,4e-3,2.0,0.05,0.15
R1=np.log(rI/a)/(2*np.pi*s1); R2=np.log(b/rI)/(2*np.pi*s2); I=V0/(R1+R2)
VIex=V0-I*R1; q0ex=I/(2*np.pi*a)/s1; qIex=-I/(2*np.pi*rI)/s1
def run(n0,nI,n2):
    e=circle(a,n0,False); i1=circle(rI,nI,True); i2=i1[::-1].copy(); o=circle(b,n2,True)
    P1=Panels([(e,'e'),(i1,'i')]); P2=Panels([(i2,'i'),(o,'o')])
    H1,G1=matrices(P1); H2,G2=matrices(P2)
    # map Omega2 interface panels to Omega1 interface panels by midpoint
    m1=P1.m[P1.tag=='i']; m2=P2.m[P2.tag=='i']
    perm=np.array([np.argmin(np.hypot(*(m1-x).T)) for x in m2])
    N=n0+2*nI+n2; A=np.zeros((N,N)); rhs=np.zeros(N)
    ie=np.arange(n0); iV=n0+np.arange(nI); iq=n0+nI+np.arange(nI); io=n0+2*nI+np.arange(n2)
    # Omega1: rows 0..n0+nI-1 ; cols of P1: [e(n0), i(nI)]
    ce=np.arange(n0); ci=n0+np.arange(nI)
    r1=np.arange(n0+nI)
    A[np.ix_(r1,ie)]=-G1[:,ce]; rhs[r1]-=H1[:,ce]@(V0*np.ones(n0))
    A[np.ix_(r1,iV)]=H1[:,ci]; A[np.ix_(r1,iq)]=-G1[:,ci]
    # Omega2: P2 cols [i(nI) , o(n2)]
    r2=n0+nI+np.arange(nI+n2); c2i=np.arange(nI); c2o=nI+np.arange(n2)
    A[np.ix_(r2,iV[perm])]+=H2[:,c2i]
    A[np.ix_(r2,iq[perm])]+=-G2[:,c2i]*(-s1/s2)
    A[np.ix_(r2,io)]=-G2[:,c2o]
    x=np.linalg.solve(A,rhs)
    q0=x[ie]; VI=x[iV]; qI=x[iq]; qo=x[io]
    err=lambda v,ex: np.linalg.norm(v-ex)/(abs(ex)*np.sqrt(len(v)))
    Ie=(s1*q0*P1.L[P1.tag=='e']).sum(); Io=(s2*qo*P2.L[P2.tag=='o']).sum()
    Lq=P1.L[P1.tag=='i']; jump=abs((s1*qI*Lq).sum()+(s2*(-s1/s2)*qI*Lq).sum())/abs(Ie)
    return err(VI,VIex),err(q0,q0ex),err(qI,qIex),abs(Ie+Io)/abs(Ie),jump
if __name__=='__main__':
    print('exact VI',VIex,'q0',q0ex,'qI',qIex,'I',I)
    for m in [(16,24,32),(24,32,48),(32,48,64),(48,64,96),(64,96,128),(96,128,192)]:
        print(m,*[f'{v:.3e}' for v in run(*m)])
